# Wayside Inn — Pixel Crawler playable slice

An independent, compact Godot 4.6.3 experiment using original Anokolisa Pixel Crawler Free Pack pixels. The Hollow Hearth repository is not part of this project.

## Play

Browser package: extract the ZIP, then open Play-Wayside-Inn.html in a recent desktop Chrome or Edge. It embeds the actual Godot WebAssembly game; allow time for startup. If local-file restrictions prevent loading, run `python3 start_game.py` (Windows: `py start_game.py`) in the extracted folder. The launcher opens a local HTTP server and your browser. Keep its terminal open; Ctrl+C stops it. WebGL 2 is required. Hosted HTTP playback was tested in Chromium; direct file opening depends on browser security settings.

Linux package: extract and run `./wayside_inn.x86_64` (if needed, `chmod +x wayside_inn.x86_64`). It requires an x86_64 Linux desktop and a compatible OpenGL driver. The executable received a headless startup check; graphical play was tested through the browser export.

Enter starts; WASD or arrows move; E interacts; Escape pauses; F5 saves. There is an optional on-screen control toggle. Gather the three forest mushrooms, enter the cliffside tavern door, cook at the upper-left stove, then serve the guest on the right. Return outside for another round. Serving earns 10 coins. New round resets progress. Progress auto-saves in Godot's user data; browser storage belongs to that browser and URL, and may be cleared in private browsing.

## Edit

Import project.godot in Godot 4.6.3. Open scenes/forest.tscn and scenes/tavern.tscn: terrain is real TileMapLayer terrain, and props are separate editable nodes with root anchors and collision bodies. Scenes are not flattened mockup pictures. F6 on main.tscn runs the slice; F5 runs the project. Standard Godot 4.6.3 export templates are needed to rebuild exports.

Native terrain is 16×16. The original dressed character uses padded 64×64 frames (four idle / six walk) anchored at (32,48); the visible character is much smaller than that frame. Rendering uses a 320×180 viewport, nearest filtering and integer scaling. At 1920×1080 that is 6×. Forest map: 384×256; tavern: 320×192. Both have fixed cameras. No arbitrary sprite enlargements.

The source dressed character provides one authored facing angle, mirrored for left movement; this slice does not invent missing directional animations. Shadows are those authored into source art; there is no dynamic lighting. The scope is two small environments and one repeatable cooking loop, without combat, a full tavern economy, sound, or a large world.

## Validation

The real Godot physics/input test tests collecting, collision blocking, both transitions, cooking consumption, serving rewards, duplicate-interaction prevention, versioned saves, and pause (234 checks including navigation steps). Run `godot --headless --fixed-fps 60 --path . --script res://tests/play_loop.gd`. This deletes the slice's existing save in its current Godot user directory; use a separate XDG_DATA_HOME for isolated testing on Linux. tests/browser_play.cjs drives actual keyboard input through the exported game with Playwright; it is a development-environment harness, not needed to play.

The supplied scenes are baked from scripts/world_factory.gd and the JSON placement manifests. To regenerate after changing that factory, run `godot --headless --path . --script res://tools/bake_worlds.gd`; this overwrites the two baked scene files, so save hand-edited scenes separately first.

## Art and redistribution

Art: Pixel Crawler – Free Pack by Anokolisa. Read ASSET_TERMS.txt. The pack allows functional game use and modification; do not sell or redistribute these sprites as a standalone asset product. This private review delivery is not permission to publish the raw project/art in a public repository. Verify the author's redistribution terms before publishing source. No Copperfern or Ninjikin grass assets are included. No new world sprites were generated.

Godot Engine is MIT licensed; see GODOT-LICENSE.txt. Its third-party notices are included in GODOT-COPYRIGHT.txt. Project code is supplied for the user's review and development; the art remains governed by its original terms.
